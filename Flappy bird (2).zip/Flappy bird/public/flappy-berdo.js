$(document).ready(function(){
    $("#main").fadeIn();
});
console.log("works~");

var diditstart = false;
var sessionScore = 0;
var highScore = 0
document.addEventListener('keyup', event => {
    
    if (event.code === 'Space' && diditstart == true) {
        sessionScore++;
        document.getElementById("points").innerHTML = sessionScore; 
    }
  })
function start(){
    if (diditstart==false){
        alert("game started, good luck");    
        document.getElementById("start").disabled = true;
        document.getElementById("end").disabled = false;
        document.getElementById("points").innerHTML = 0;
        sessionScore = 0;
        diditstart = true;
    }else
        alert("how")
}
function win(){
    if (diditstart==true){
        alert("ya did it");
        if(sessionScore>highScore){
            highScore=sessionScore;
            document.getElementById("highscore").innerHTML=highScore;
            let user =prompt("ayo new high score\nthis ones for the books, whats your name chief?","");
            if(user == null || user == ""){
                alert("aight nvm")
            }else{
                localStorage.setItem(user, sessionScore)
            }
        }
        diditstart = false;
        document.getElementById("start").disabled = false;
        document.getElementById("end").disabled = true;
    }else
        alert("bruh didnt even start the game what")
}