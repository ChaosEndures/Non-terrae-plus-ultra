$(document).ready(function(){
    $("#main").fadeIn();
});
console.log("works~");

var diditstart = false;
var sessionScore = 0;
var highScore = 0
var user = ""

function change(){
    document.getElementById("start").disabled = true;
    document.getElementById("end").disabled = true;
    sessionScore = 0;
    document.getElementById("points").innerHTML = sessionScore;
    diditstart = false
}

function saveUser(){
    user = document.getElementById("username").value;
    console.log(user)
    if(localStorage.getItem(user) == null){
        localStorage.setItem(user, 0);
        highScore = 0
        document.getElementById("highscore").innerHTML = 0;
        document.getElementById("greeting").innerHTML = "welcome to flappy bird, " + user;
    }else{
        highScore = localStorage.getItem(user, sessionScore);
        document.getElementById("highscore").innerHTML = localStorage.getItem(user, sessionScore);
        document.getElementById("greeting").innerHTML = "welcome back, " + user;
    }
    document.getElementById("start").disabled = false;
}

document.addEventListener('keyup', event => {
    
    if (event.code === 'Space' && diditstart == true) {
        sessionScore++;
        document.getElementById("points").innerHTML = sessionScore; 
    }
  })
function start(){
    if (diditstart==false){
        alert("game started, good luck");    
        document.getElementById("start").disabled = true;
        document.getElementById("end").disabled = false;
        document.getElementById("points").innerHTML = 0;
        document.getElementById("greeting").innerHTML = "";
        sessionScore = 0;
        diditstart = true;
    }else
        alert("how")
}
function win(){
    if (diditstart==true){
        if(sessionScore>highScore){
            highScore=sessionScore;
            document.getElementById("highscore").innerHTML=highScore;
            alert("ayo new high score doofus");
            if(user == null || user == ""){
                alert("aight nvm")
            }else{
                localStorage.setItem(user, sessionScore)
            }
        }
        diditstart = false;
        document.getElementById("start").disabled = false;
        document.getElementById("end").disabled = true;
    }else
        alert("bruh didnt even start the game what")
}