var diditstart = false;
var highScore = 0
var user = ""

function change(){
    sessionScore = 0;
    document.getElementById("points").innerHTML = sessionScore;
    diditstart = false
}

function saveUser(){
    user = document.getElementById("username").value;
    console.log(user)
    //document.getElementById('greeting').style.opacity = 0;
    if(localStorage.getItem(user) == null){
        localStorage.setItem(user, 0);
        highScore = 0
        document.getElementById("highscore").innerHTML = 0;
        document.getElementById("greeting").innerHTML = "welcome to flappy bird, " + user;
    }else{
        highScore = localStorage.getItem(user, sessionScore);
        document.getElementById("highscore").innerHTML = localStorage.getItem(user, sessionScore);
        document.getElementById("greeting").innerHTML = "welcome back, " + user;
    }
    diditstart = true;
}

function notification(){
    $('#greeting').fadeOut(2000);
    console.log("notif ok")
    if(localStorage.getItem(user) != null){
        setTimeout(notification2, 2000);
    }
}

function notification2(){
    document.getElementById("greeting").innerHTML = "highscore loaded~";
    document.getElementById("greeting").style.opacity = '1';
    console.log(document.getElementById('greeting').style.opacity)
    $('#greeting').fadeOut(2000);
}

document.addEventListener('keydown', event => {  
    if (event.code === 'Space' && diditstart == true) {
        sessionScore++; 
        accelerate(-0.5)
    }
})

document.addEventListener('keyup', event => {  
    if (event.code === 'Space' && diditstart == true) {
        accelerate(0.25)
    }
})

function start(){
    if (diditstart==false){  
        document.getElementById("points").innerHTML = 0;
        document.getElementById("greeting").innerHTML = "";
        sessionScore = 0;
        diditstart = true;
    }else
        alert("how")
}
function win(){
    if (diditstart==true){
        if(sessionScore>highScore){
            highScore=sessionScore;
            document.getElementById("highscore").innerHTML=highScore;
            alert("ayo new high score doofus");
            if(user == null || user == ""){
                alert("aight nvm")
            }else{
                localStorage.setItem(user, sessionScore)
            }
        }
        diditstart = false;
    }else
        alert("bruh didnt even start the game what")
}