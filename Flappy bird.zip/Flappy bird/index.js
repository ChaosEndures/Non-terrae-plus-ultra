const express = require('express');
const app = express();
const path = require('path');


app.use(express.static(path.join(__dirname, 'public')));
app.use('/jquery', express.static(__dirname + '/node_modules/jquery/dist/'));

app.get('/', function (req, res) {  
    res.sendFile(path.join(__dirname+'/main-page.html'));
})
app.get('/flappy-bird', function (req, res) {  
    res.sendFile(path.join(__dirname+'/flappy-bird.html'));
})
app.get('/highscore', function (req,  res)  {
    res.sendFile(path.join(__dirname+'/highscores.html'));
})
app.get('/about-us', function (req,  res)  {
    res.sendFile(path.join(__dirname+'/about-us.html'));
})
app.listen(3030) ;